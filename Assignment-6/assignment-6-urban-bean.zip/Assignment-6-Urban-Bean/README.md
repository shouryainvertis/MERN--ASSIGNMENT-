# Assignment 6 — Flexbox Layouts: Urban Bean Café

## Objective
Practise one-dimensional page layouts using CSS Flexbox.

## Project Theme
**Urban Bean Café** is a fictional café with a coffee-brown, cream, caramel and sage colour palette. It is a separate theme from the previous landing-page assignment.

## Pages Included
- `menu.html` — Flexbox navigation bar and café introduction.
- `login.html` — Login form centred horizontally and vertically using Flexbox.
- `products.html` — Eight menu cards using `display: flex`, `flex-wrap`, `gap`, and flexible card sizing. Add buttons show a demo message.
- `navbar-hero.html` — Flexbox navbar and hero section arranged with `flex-direction: column`.

## Technologies
HTML5, embedded CSS3, Flexbox, CSS custom properties, responsive media queries, semantic HTML, image alt text and labelled form fields.

## How to Run
1. Download and extract the ZIP.
2. Open `menu.html` in a browser.
3. Use the navigation links to open the menu/products and login pages.
4. Internet is needed for remote Unsplash photos.

## Notes
- This is a practice project, not a real café ordering system.
- Login is a visual form; real authentication requires a secure backend.
- Product buttons only display a demo confirmation; they do not create a real cart or process payments.
- Prices and café details are fictional.
- Images load from external Unsplash URLs and may not show offline.

## What I Learned
- Building horizontal navigation with Flexbox
- Centring a login card on the page
- Wrapping product cards on different screen sizes
- Using gaps and flexible card widths
- Making a column-oriented hero section
- Keeping HTML and CSS together in each standalone file
